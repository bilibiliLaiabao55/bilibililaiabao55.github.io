#include<bits/stdc++.h>
#include<windows.h>
using namespace std;

struct Note{
	int length;
	float pitch;
};

int SongLength=0;
vector<Note> Notes;

int main(){
	printf("Hello!\nThank you for using my tool!\n");
	printf("let's start\n");
	while(true){
		printf("Note(pitch length):\n");
		Note NewNote;
		scanf("%f %d", &NewNote.pitch, &NewNote.length);
		printf("pitch:%f length:%d, right?(RIGHT:0, NO:1)\n", NewNote.pitch, NewNote.length);
		int right=0;
		scanf("%d", &right);
		if (right==1){
			continue;
		}
		Notes.push_back(NewNote);
		printf("what do you want to do?\n 0.Next Note\n 1.Play\n 2.Over\n");
		int choose;
		scanf("%d", &choose);
		if(choose == 0){
			continue;
		}
		if(choose == 1){
			printf("SongLength:%d\n", Notes.end()-Notes.begin());
			for(int i=0;i<Notes.end()-Notes.begin();++i){
				printf("Note:%d, pitch:%f, length:%d\n", i, Notes[i].pitch, Notes[i].length);
				Beep(Notes[i].pitch, Notes[i].length);
			}
		}
		if(choose == 2){
			break;
		}
	}
	 return 0;
}

